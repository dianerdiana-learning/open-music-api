import { MigrationBuilder } from 'node-pg-migrate';

export async function up(pgm: MigrationBuilder): Promise<void> {
  pgm.createTable('albums', {
    id: {
      type: 'varchar(50)', // or text, depending on your comfort
      primaryKey: true,
      notNull: true,
    },
    name: { type: 'varchar(255)', notNull: true },
    year: { type: 'integer', notNull: true },
    cover: { type: 'varchar(255)' },
    created_at: {
      type: 'timestamp',
      notNull: true,
      default: pgm.func('now()'),
    },
    updated_at: {
      type: 'timestamp',
      notNull: true,
      default: pgm.func('now()'),
    },
  });
}

export async function down(pgm: MigrationBuilder): Promise<void> {
  pgm.dropTable('albums');
}
